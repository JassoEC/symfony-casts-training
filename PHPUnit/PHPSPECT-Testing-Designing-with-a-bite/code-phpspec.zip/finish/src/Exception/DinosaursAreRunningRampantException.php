<?php

namespace App\Exception;

final class DinosaursAreRunningRampantException extends \Exception
{
}
