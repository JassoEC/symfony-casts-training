<?php

return [
    'GITHUB_TOKEN' => null,
];
